
#include <stdio.h>
#include <stdbool.h>
#define B 5

int L[B][B] = {//5 e 5 lik bi matris tablosu olusturduk
    {1,0,1,1,1},// buras� labirenttir 1 gecilebilecek yollar� 0 ise duvar anlam�na gel�r 
    {1,0,1,0,1},
    {1,1,1,0,1},
    {0,0,1,1,1},
    {1,1,1,0,1}
};

int C[B][B];//c�z�m yoludur 

bool coz(int x, int y) {//burda kontrol ediyoruz
    if (x<0 || y<0 || x>=B || y>=B || L[x][y]==0 || C[x][y])    //e�er labirentin disina cikt�ysa,eger bi duvarla kars�last�ysa,eger daha �nce bu yoldan gecildiyse o yolu b�rak�r
    return false;
   
    C[x][y] = 1;
   
    if (x==B-1&&y==B-1)//eger �iki�a ulas�ld�ysa yani kordinatlar B-1 e B-1 e olduysa fonks�yon son bulur 
     return true;
    
    if (coz(x+1,y) || coz(x,y+1) || coz(x-1,y) || coz(x,y-1))    // burada 1.de bir ad�m saga gitmeyi 2.de bir ad�m asagi gitmeyi 3.de bir ad�m sola gitmey� 4.de bir adim yukar� gitmey� dener
    return true;//eger y�nlerden biri 
    C[x][y] = 0;
    return false;
}

int main() {
    if (coz(0,0)) {//sol �stten aramaya baslar
        printf("Cikis yolu bulundu:\n");
        
	   for(int i=0 ; i<B ; i++){
            for(int j=0 ; j<B ;j++) 
		printf("%d ", C[i][j]);// o andak� koordinatta bulunan deger� ekrana yazd�r�r
            printf("\n");
        }
    } else
       
	   printf("Cikis yolu yok..\n");
    
    
    
    
    return 0;
}



