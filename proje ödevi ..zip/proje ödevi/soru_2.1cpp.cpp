#include <stdio.h>
#include<stdlib.h>      //fonksiyonlar� kullanabilmemiz icin
int ucgensayi(int n){   //�zyinelemel� fonksiyon kulland�k ve fonksiyon kendisini cag�rarak n den baslay�p 1 e kadar azaltarak islem yapar
    
    if (n == 1)        //burda kosul yazmam�z�n sebebi sonsuza kadar devam etmesini engeller ve b� yerde bitmesini saglar
        
	   return 1;

    
    return n + ucgensayi(n - 1);   //her seferde say�y� al�p birer birer azaltarak tekrar kend�n� cag�r�or
}

int main()
{
    int adet, i;

    printf("Kac tane ucgen sayi yazdirmak istersiniz: ");   //kullan�c�dan kac tane �cgen say� olmas�n� istedigini istedik scanfle de adet degisken�ne atad�k
    scanf("%d",&adet);

    for (i=1 ; i<=adet ; i++)
    {
        printf(" %d ",ucgensayi(i));
    }

    return 0;
}
