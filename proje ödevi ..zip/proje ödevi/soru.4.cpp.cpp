#include <stdio.h>
#include<stdlib.h>
#include <string.h>//string kullanacagimiz icin

    int main(){
    char mesaj[100];     //kullanicidan alacag�m�z c�mley� saklamak icin hafizada 100 karakterlik alan ay�r�r
    int anahtar_deger;
    int secim;
    
    printf("1=sifreleme	\n");      //sifrelemek istiyorsa
    printf("2=geri cozme \n");    //cozmek ist�yorsa
    printf("secim\n");
    scanf("%d",&secim);
    getchar();       //enter kulland�g�m�z icin yazdik
    
    
  printf("Sifrelenmesini istediginiz mesaji giriniz: ");
  fgets(mesaj, sizeof(mesaj), stdin);     // scanf yerine fgets kullanma sebebimiz boslugu da okuyabilmektir
  
  
  printf("Anahtar degeri giriniz");      //kullan�c�dan verilem c�mledek� harfler�n kac adim ileriye kayd�r�lacag�n� bel�rlemes�n� istedik
  scanf("%d", &anahtar_deger);

    for (int i = 0; mesaj[i] !='\0'; i++)     //burdak� d�ng�de mesaj�n bas�ndan \0 a kadar ilerler 
    {
    	     if (mesaj[i] >= 'a' && mesaj[i] <= 'z')      // burda da k�c�k harflerde sifreleme icin ayr� buyuk harflerde s�freleme icin formulu uygular
    	if(secim==1){//1 secildiyse
	      mesaj[i] = (mesaj[i] - 'a' + anahtar_deger) % 26 + 'a'; 
	      
	}
      else{
           
	     //2 secildiyse
		  mesaj[i] = (mesaj[i] - 'a' - anahtar_deger+26) % 26 + 'a';    // harfin alfabedek� yer�n� bulur sonra anahtar deger kadar kayd�r�l�r eger z girilirse de tekrar basa d�nd�r�l�r %26 bu yuzdend�r 
      
}//b�y�k harfler icin ayn� islemler
	   else if (mesaj[i] >= 'A' && mesaj[i] <= 'Z')
           if(secim==1){
           	  mesaj[i] = (mesaj[i] - 'A' + anahtar_deger) % 26 + 'A'; 
	     }else{
	     
		  mesaj[i] = (mesaj[i] - 'A' - anahtar_deger+26) % 26 + 'A'; 
		  }
		        
    }
    
if(secim==1){

   printf("Sifrelenmis Mesaj: %s", mesaj); // ve burda ekrana yazd�rd�k s�frelenm�s hal�n�
   }   else{
   	printf("cozulmus s�fre: %s",mesaj);//ve burda da c�zulmus hal�n� yazd�rd�k
   }                                         
   
    return 0;
}
