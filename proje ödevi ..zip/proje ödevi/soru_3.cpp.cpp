#include<stdio.h>


int asal_mi(int x){     //bir sayinin asal olup olmad�g�n� kontrol eder
    if (x < 2)
        return 0;

    for (int i = 2; i * i <= x; i++) {    //2 den ba�lay�p karek�k�ne kadar olan sayilara b�ler tam bol�n�rse 0 bolunmezse 1 yan� asald�r
        if (x % i == 0)
            return 0;
    }
    return 1;
}

int unlu_mu(char c) {   //verilen char�n sesli harflerden biri olup olmad�g�n� kontrol eder
    return (c =='a' || c =='e' || c =='i' || c =='o' || c =='u');
}

int main() {
    char a, b;
    int sayac = 0;

    printf("Gecerli Isimler:\n");

    for (a = 'a'; a <= 'z'; a++) {        //ilk harfi a dan z ye kadar tek tek degistirir 
        for (b = 'a'; b <= 'z'; b++) {   //burda da ikinci harfe ayn�s�n� yaparak tek tek degistirir
//bu ic i�e d�ng�lerle 26*26 =676 tane harfi tek tek kontrol eder 
            
            if (unlu_mu(a) && !unlu_mu(b) || !unlu_mu(a) && unlu_mu(b)) {     // burda harflerden sadece bir tanesinin �nl� olmas�n� sartland�r�r

                int ascii_toplam = a + b + a;      // asc�� degerler�n� topluyoruz burda 

                if (asal_mi(ascii_toplam)) {     //hesaplaman�n toplam� yan� asc��_toplam,asal_mi fonksiyonuna g��derilir 
                    sayac++;            // g�nderilen toplam asalsa sayac 1 art�l�r
                    printf("%2d. %c%c%c\n", sayac, a, b, a);    // ekrana kacinci isim ve harf birles�m�n� yani ismi yazd�r�l�r
                }
            }
        }
    }

    printf("\nToplam gecerli isim sayisi: %d\n", sayac);

    return 0;
}
