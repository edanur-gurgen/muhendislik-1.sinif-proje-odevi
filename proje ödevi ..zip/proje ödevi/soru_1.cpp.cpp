#include <stdio.h>      //printf scanf gibi fonksiyonlar� her seferinde uzun uzun kodlamak yer�ne bu kutuphayen� ekl�yoruz
#include <stdlib.h>    //fonks�yonlari kullanabilmek icin standart kutuphaneye iht�yac�m�z var
#include <time.h>     //zaman ilerledikce rastgele say�lar �reten fonksiyon icin time k�t�phanesine iht�yac�m�z var

#define AY 12 
  //define � kullanmamizin sebebi AY g�rd�g� yere 12 yazmasi icin



void ciroUret(int dizi[]) {     //herhangi bir degeri d�ndurmeyeceg�m�zde void kullan�yoruz
   // 12 ayl�k rastgele ciro �retebilmek icin cirouret fonks�yonunu kulland�k ve for d�ng�s�yle yapt�k
for (int i = 0; i < AY; i++) {
dizi[i] = (rand() % 9001) + 1000;    // 1000 10000 aras�nda degeri nas�l yapacag�m� bilemedim yapay zekadan bakt�m
}
}

void ciroListele(int dizi[]) {    //ay ay ekrana cirolar� yazan bi fonks�yon yazd�k ve 12.aya kadar ekrana yazd�ran for d�ngusu yapt�k 
printf("Aylik Cirolar :\n");
for (int i = 0; i < AY; i++) {
printf("%2d. Ay: %5d\n", i+1, dizi[i]);
}
}

//burda verileri * i�aret� ile grafiklest�rd�k 
void yatay_grafik(int dizi[]) {    //yatay graik yazd�rd�k
printf("\n YATAY GRAFIK\n");
printf("(Her * = 1000 TL)\n");

for (int i = 0; i < AY; i++) {  
    int yildiz = dizi[i] / 1000;   // her ay�n cirosunu 1000 e b�ler ve o kadar * koyar  
    printf("%2d: ", i+1);  
    for (int j = 0; j < yildiz; j++) {  
        printf("*");  
    }  
    printf("\n");  
}

}


void dikey_grafik (int dizi[]) {    //dikey grafigi yazd�rd�k
int yildizsayisi[AY];
int max = 0;

for (int i = 0; i < AY; i++) {      //aylar�n y�ld�z say�lar�n� hesaplar en cok olan� max olarak bel�rler
    yildizsayisi[i] = dizi[i]/1000;  
    if (yildizsayisi[i] > max)  
        max = yildizsayisi[i];  
}  

printf("\n DIKEY GRAFIK \n");  
printf("(Her * = 1000 TL)\n");  


for (int seviye = max; seviye >= 1; seviye--) {   //max seviyeden kat kat iner ve e�er o ay�n cirosu esit veya buyukse * ekler degilse bosluk ekler
    for (int i = 0; i < AY; i++) {  
        if (yildizsayisi[i] >= seviye)  
            printf(" * ");  
        else  
            printf("   ");  
    }  
    printf("\n");  
}  


for (int i = 0; i < AY; i++) {     //burda da tablonun alt�ndak� 1.ay 2.ay 3.ay yaz�lar�n� yazar
    printf("%2d ", i+1);  
}  


}

int main() {
int cirolar[AY];

srand(time(NULL));     //zaman s�rekli ilerledigi icin rasgele sayilar vermesini saglar

ciroUret(cirolar);  
ciroListele(cirolar);  

yatay_grafik(cirolar);  
dikey_grafik(cirolar);  

return 0;

} 
